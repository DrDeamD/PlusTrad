import { useCallback, useEffect, useMemo, useState } from "react";
import { computeWeightedConsensus } from "./engine/confluenceEngine";
import { applyExecutionFilter } from "./engine/executionFilter";
import { getTradingSession } from "./engine/sessionEngine";
import { detectMarketRegime } from "./engine/regimeEngine";
import { buildRiskModel } from "./engine/riskModel";
import { PRO_AGENTS, evaluateProAgent } from "./engine/proAgents";
import type { AgentSignal, ProMarketState } from "./engine/types";
import {
  buildProMarketState,
  fetchCandlesWithFallback,
  fetchNewsWithFallback,
} from "./services/apiService";
import { cn } from "./utils/cn";

const PAIRS = ["XAU/USD", "EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD"];

type PairSnapshot = {
  ms: ProMarketState;
  signals: AgentSignal[];
  consensus: ReturnType<typeof computeWeightedConsensus>;
};

type PairMap = Record<string, PairSnapshot>;

function decisionColor(decision: string): string {
  if (decision === "Buy") return "text-emerald-400";
  if (decision === "Sell") return "text-rose-400";
  if (decision === "No Trade") return "text-orange-300";
  return "text-amber-300";
}

function sentimentBadge(value: string) {
  if (value === "high") return "border-rose-500/30 bg-rose-500/10 text-rose-300";
  if (value === "medium") return "border-amber-500/30 bg-amber-500/10 text-amber-300";
  return "border-emerald-500/30 bg-emerald-500/10 text-emerald-300";
}

function keyStats(current?: PairSnapshot) {
  if (!current) return [] as Array<[string, string]>;
  return [
    ["Regime", current.ms.regime],
    ["Session", current.ms.session],
    ["Trend", `${current.ms.trend} / HTF ${current.ms.htfTrend}`],
    ["ADX", current.ms.adx.toFixed(1)],
    ["RSI", current.ms.rsi.toFixed(1)],
    ["ATR", String(current.ms.atr)],
    ["Spread", current.ms.spreadPips ? `${current.ms.spreadPips}` : "n/a"],
    ["Bias", current.consensus.signedBias.toFixed(2)],
  ];
}

export default function App() {
  const [activePair, setActivePair] = useState("XAU/USD");
  const [data, setData] = useState<PairMap>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cycle, setCycle] = useState(0);

  const runCycle = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const nextData: PairMap = {};
      for (const pair of PAIRS) {
        const [{ candles: m5Candles }, { candles: m15Candles }, { candles: h1Candles }, { news }] = await Promise.all([
          fetchCandlesWithFallback(pair, "5min", 180),
          fetchCandlesWithFallback(pair, "15min", 160),
          fetchCandlesWithFallback(pair, "1h", 220),
          fetchNewsWithFallback(pair),
        ]);

        const ms = buildProMarketState({ pair, m5Candles, m15Candles, h1Candles, news });
        ms.session = getTradingSession();
        ms.regime = detectMarketRegime(ms);

        const signals = PRO_AGENTS.map((agent) => {
          let signal = evaluateProAgent(agent, ms);
          signal = { ...signal, ...buildRiskModel({ signal, ms }) };
          signal = applyExecutionFilter(signal, ms);
          return signal;
        });

        const consensus = computeWeightedConsensus(signals);
        nextData[pair] = { ms, signals, consensus };
      }
      setData(nextData);
      setCycle((value) => value + 1);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void runCycle();
  }, [runCycle]);

  const current = data[activePair];
  const topSignals = useMemo(() => {
    if (!current) return [] as AgentSignal[];
    return [...current.signals].sort((a, b) => (b.score * (b.performanceFactor ?? 1)) - (a.score * (a.performanceFactor ?? 1))).slice(0, 3);
  }, [current]);
  const blockedReasons = useMemo(() => {
    if (!current) return [] as string[];
    return Array.from(new Set(current.signals.flatMap((signal) => signal.reasonCodes ?? []).filter((code) => code.startsWith("BLOCK_"))));
  }, [current]);

  return (
    <div className="min-h-screen px-4 py-6 text-slate-100 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="mb-6 rounded-3xl border border-cyan-500/15 bg-slate-900/70 p-6 shadow-2xl shadow-cyan-950/20 backdrop-blur">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <div className="mb-2 inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-400/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-cyan-200">
                MIROFISH Trading PRO+
              </div>
              <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Forex + Gold Daytrading Engine</h1>
              <p className="mt-2 max-w-3xl text-sm text-slate-300 sm:text-base">
                Regime-aware, session-aware, multi-timeframe dashboard with stricter no-trade logic,
                weighted consensus, and specialized agents for intraday trading.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <span className="rounded-xl border border-slate-700 bg-slate-950/70 px-3 py-2 text-sm text-slate-300">Cycle #{cycle}</span>
              <button
                onClick={() => void runCycle()}
                className="rounded-xl border border-cyan-400/30 bg-cyan-400/10 px-4 py-2 font-semibold text-cyan-200 transition hover:bg-cyan-400/20"
              >
                {loading ? "Refreshing..." : "Run now"}
              </button>
            </div>
          </div>
        </div>

        <div className="mb-6 flex flex-wrap gap-2">
          {PAIRS.map((pair) => {
            const snapshot = data[pair];
            return (
              <button
                key={pair}
                onClick={() => setActivePair(pair)}
                className={cn(
                  "rounded-2xl border px-4 py-3 text-left transition",
                  activePair === pair
                    ? "border-cyan-400/40 bg-cyan-400/10 text-cyan-200"
                    : "border-slate-800 bg-slate-900/70 text-slate-200 hover:border-slate-700 hover:bg-slate-900",
                )}
              >
                <div className="mono text-sm font-semibold">{pair}</div>
                <div className={cn("mt-1 text-xs font-medium", snapshot ? decisionColor(snapshot.consensus.direction) : "text-slate-400")}>
                  {snapshot ? snapshot.consensus.direction : "..."}
                </div>
              </button>
            );
          })}
        </div>

        {error ? (
          <div className="rounded-2xl border border-rose-500/30 bg-rose-500/10 p-4 text-rose-200">{error}</div>
        ) : null}

        <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
          <div className="space-y-6">
            <section className="rounded-3xl border border-slate-800 bg-slate-900/70 p-5 shadow-lg backdrop-blur">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-semibold">Market state</h2>
                  <p className="text-sm text-slate-400">Selected pair: <span className="mono text-slate-200">{activePair}</span></p>
                </div>
                {current ? (
                  <span className={cn("rounded-xl border px-3 py-2 text-sm font-semibold", sentimentBadge(current.ms.newsImpact))}>
                    News {current.ms.newsImpact}
                  </span>
                ) : null}
              </div>

              {loading && !current ? <div className="text-slate-400">Loading live structure...</div> : null}
              {current ? (
                <>
                  <div className={cn("mb-5 text-5xl font-black tracking-tight", decisionColor(current.consensus.direction))}>
                    {current.consensus.direction}
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                    {keyStats(current).map(([label, value]) => (
                      <div key={label} className="rounded-2xl border border-slate-800 bg-slate-950/60 p-4">
                        <div className="text-xs uppercase tracking-[0.18em] text-slate-500">{label}</div>
                        <div className="mt-2 text-sm font-semibold text-slate-100">{value}</div>
                      </div>
                    ))}
                  </div>
                </>
              ) : null}
            </section>

            <section className="rounded-3xl border border-slate-800 bg-slate-900/70 p-5 shadow-lg backdrop-blur">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-xl font-semibold">Agent grid</h2>
                <span className="text-sm text-slate-400">{current?.signals.length ?? 0} agents</span>
              </div>
              <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                {current?.signals.map((signal) => (
                  <div key={signal.id} className="rounded-2xl border border-slate-800 bg-slate-950/60 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="font-semibold text-slate-100">{signal.name}</div>
                        <div className="text-xs text-slate-500">{signal.style}</div>
                      </div>
                      <div className={cn("text-sm font-semibold", decisionColor(signal.decision))}>{signal.decision}</div>
                    </div>
                    <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <div className="text-xs uppercase tracking-[0.15em] text-slate-500">Score</div>
                        <div className="mono mt-1">{signal.score.toFixed(2)}</div>
                      </div>
                      <div>
                        <div className="text-xs uppercase tracking-[0.15em] text-slate-500">Confidence</div>
                        <div className="mono mt-1">{Math.round(signal.confidence * 100)}%</div>
                      </div>
                      <div>
                        <div className="text-xs uppercase tracking-[0.15em] text-slate-500">Influence</div>
                        <div className="mono mt-1">{signal.influence.toFixed(2)}</div>
                      </div>
                      <div>
                        <div className="text-xs uppercase tracking-[0.15em] text-slate-500">Perf</div>
                        <div className="mono mt-1">{(signal.performanceFactor ?? 1).toFixed(2)}</div>
                      </div>
                    </div>
                    <p className="mt-4 text-sm text-slate-300">{signal.reasoning}</p>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {(signal.reasonCodes ?? []).slice(0, 4).map((code) => (
                        <span key={code} className="rounded-full border border-slate-700 bg-slate-900 px-2.5 py-1 text-[11px] text-slate-300">
                          {code}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>

          <div className="space-y-6">
            <section className="rounded-3xl border border-slate-800 bg-slate-900/70 p-5 shadow-lg backdrop-blur">
              <h2 className="mb-4 text-xl font-semibold">Consensus & diagnostics</h2>
              {current ? (
                <div className="space-y-4">
                  <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-4">
                    <div className="text-xs uppercase tracking-[0.18em] text-slate-500">Final bias</div>
                    <div className={cn("mt-2 text-4xl font-black", decisionColor(current.consensus.direction))}>{current.consensus.direction}</div>
                    <div className="mono mt-2 text-sm text-slate-300">Signed bias {current.consensus.signedBias.toFixed(3)} · Confidence {Math.round(current.consensus.conf * 100)}%</div>
                  </div>
                  <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-4">
                    <div className="mb-2 text-xs uppercase tracking-[0.18em] text-slate-500">Top supporting agents</div>
                    <div className="space-y-3">
                      {topSignals.map((signal) => (
                        <div key={signal.id} className="flex items-center justify-between text-sm">
                          <span>{signal.name}</span>
                          <span className={decisionColor(signal.decision)}>{signal.decision}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-4">
                    <div className="mb-2 text-xs uppercase tracking-[0.18em] text-slate-500">Blocked reasons</div>
                    <div className="flex flex-wrap gap-2">
                      {blockedReasons.length ? blockedReasons.map((reason) => (
                        <span key={reason} className="rounded-full border border-rose-500/20 bg-rose-500/10 px-2.5 py-1 text-xs text-rose-200">{reason}</span>
                      )) : <span className="text-sm text-slate-400">No major blocks</span>}
                    </div>
                  </div>
                </div>
              ) : null}
            </section>

            <section className="rounded-3xl border border-slate-800 bg-slate-900/70 p-5 shadow-lg backdrop-blur">
              <h2 className="mb-4 text-xl font-semibold">Risk box</h2>
              {current ? (
                (() => {
                  const best = topSignals.find((signal) => signal.decision === current.consensus.direction) ?? topSignals[0];
                  return best ? (
                    <div className="space-y-4">
                      <div>
                        <div className="text-sm text-slate-400">Reference setup</div>
                        <div className="mt-1 font-semibold text-slate-100">{best.name}</div>
                      </div>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3">
                          <div className="text-xs uppercase tracking-[0.15em] text-slate-500">Entry</div>
                          <div className="mono mt-2">{best.entry ?? "—"}</div>
                        </div>
                        <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3">
                          <div className="text-xs uppercase tracking-[0.15em] text-slate-500">SL</div>
                          <div className="mono mt-2">{best.sl ?? "—"}</div>
                        </div>
                        <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3">
                          <div className="text-xs uppercase tracking-[0.15em] text-slate-500">TP1</div>
                          <div className="mono mt-2">{best.tp1 ?? "—"}</div>
                        </div>
                        <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3">
                          <div className="text-xs uppercase tracking-[0.15em] text-slate-500">TP2</div>
                          <div className="mono mt-2">{best.tp2 ?? "—"}</div>
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-3 text-sm">
                        <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3">
                          <div className="text-xs uppercase tracking-[0.15em] text-slate-500">R:R</div>
                          <div className="mono mt-2">{best.rr ?? "—"}</div>
                        </div>
                        <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3">
                          <div className="text-xs uppercase tracking-[0.15em] text-slate-500">Risk pips</div>
                          <div className="mono mt-2">{best.riskPips ?? "—"}</div>
                        </div>
                        <div className="rounded-2xl border border-slate-800 bg-slate-950/60 p-3">
                          <div className="text-xs uppercase tracking-[0.15em] text-slate-500">Class</div>
                          <div className="mono mt-2">{best.riskClass ?? "—"}</div>
                        </div>
                      </div>
                    </div>
                  ) : <div className="text-sm text-slate-400">No setup selected.</div>;
                })()
              ) : null}
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
