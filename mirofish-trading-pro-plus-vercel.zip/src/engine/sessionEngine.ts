import type { SessionLabel } from "./types";

export function getTradingSession(date = new Date()): SessionLabel {
  const h = date.getUTCHours();
  if (h >= 0 && h < 6) return "ASIA";
  if (h >= 6 && h < 7) return "LONDON_PREOPEN";
  if (h >= 7 && h < 12) return "LONDON";
  if (h >= 12 && h < 15) return "LONDON_NY_OVERLAP";
  if (h >= 15 && h < 20) return "NEW_YORK";
  if (h >= 20 && h < 22) return "LATE_NY";
  return "OFF_HOURS";
}
