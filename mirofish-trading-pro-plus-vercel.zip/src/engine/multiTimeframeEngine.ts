import type { Candle } from "../services/apiService";
import { calculateEMA } from "./indicatorEngine";
import type { MultiTFState, TrendBias } from "./types";

function getTrend(candles: Candle[]): TrendBias {
  if (candles.length < 55) return "neutral";
  const closes = candles.map((c) => c.close);
  const ema21 = calculateEMA(closes, 21);
  const ema50 = calculateEMA(closes, 50);
  const last = closes[closes.length - 1];
  if (ema21 > ema50 && last >= ema21) return "bullish";
  if (ema21 < ema50 && last <= ema21) return "bearish";
  return "neutral";
}

export function buildMultiTFState(params: {
  m5Candles: Candle[];
  m15Candles: Candle[];
  h1Candles: Candle[];
}): MultiTFState {
  const m5Trend = getTrend(params.m5Candles);
  const m15Trend = getTrend(params.m15Candles);
  const h1Trend = getTrend(params.h1Candles);

  return {
    m5Trend,
    m15Trend,
    h1Trend,
    alignedBullish: h1Trend === "bullish" && m15Trend === "bullish",
    alignedBearish: h1Trend === "bearish" && m15Trend === "bearish",
    conflict:
      (h1Trend === "bullish" && m15Trend === "bearish") ||
      (h1Trend === "bearish" && m15Trend === "bullish"),
  };
}
