import type { AgentSignal, ProMarketState } from "./types";
import { RC } from "./reasonCodes";

function styleIsTrend(style: string): boolean {
  return /trend|momentum|continuation|breakout/i.test(style);
}

function styleIsReversal(style: string): boolean {
  return /reversal|mean reversion|liquidity/i.test(style);
}

function allowedSpread(pair: string): number {
  if (pair === "XAU/USD") return 35;
  if (pair === "GBP/USD") return 3;
  return 2.5;
}

export function applyExecutionFilter(signal: AgentSignal, ms: ProMarketState): AgentSignal {
  const next: AgentSignal = {
    ...signal,
    reasonCodes: [...(signal.reasonCodes ?? [])],
    blocked: signal.blocked ?? false,
  };

  if (next.decision !== "Buy" && next.decision !== "Sell") return next;

  if (ms.newsImpact === "high") {
    next.decision = "No Trade";
    next.blocked = true;
    next.reasonCodes?.push(RC.BLOCK_NEWS);
  }
  if (ms.regime === "DEAD_MARKET") {
    next.decision = "No Trade";
    next.blocked = true;
    next.reasonCodes?.push(RC.BLOCK_DEAD_MARKET);
  }
  if (styleIsTrend(next.style) && ms.adx < 16) {
    next.decision = "No Trade";
    next.blocked = true;
    next.reasonCodes?.push(RC.BLOCK_LOW_ADX);
  }
  if (styleIsReversal(next.style) && ms.adx > 30) {
    next.decision = "No Trade";
    next.blocked = true;
    next.reasonCodes?.push(RC.BLOCK_HIGH_ADX_REVERSAL);
  }
  if ((ms.spreadPips ?? 0) > allowedSpread(ms.pair)) {
    next.decision = "No Trade";
    next.blocked = true;
    next.reasonCodes?.push(RC.BLOCK_SPREAD);
  }
  if (ms.htfTrend !== "neutral") {
    if ((next.decision === "Buy" && ms.htfTrend === "bearish") || (next.decision === "Sell" && ms.htfTrend === "bullish")) {
      next.decision = "No Trade";
      next.blocked = true;
      next.reasonCodes?.push(RC.BLOCK_HTF_CONFLICT);
    }
  }
  if ((next.rr ?? 0) < 1.6) {
    next.decision = "No Trade";
    next.blocked = true;
    next.reasonCodes?.push(RC.BLOCK_LOW_RR);
  }
  if ((next.score ?? 0) < 0.62) {
    next.decision = "No Trade";
    next.blocked = true;
    next.reasonCodes?.push(RC.BLOCK_WEAK_CONFLUENCE);
  }

  return next;
}
