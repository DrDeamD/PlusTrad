import type { Candle } from "../services/apiService";
import type { LiquidityState, SessionRanges } from "./types";

function clamp(v: number, min = 0, max = 1): number {
  return Math.max(min, Math.min(max, v));
}

function candleRange(c: Candle): number {
  return Math.max(c.high - c.low, 1e-9);
}

export function detectLiquidityState(params: {
  candles: Candle[];
  ranges?: SessionRanges;
}): LiquidityState {
  const { candles, ranges } = params;
  if (candles.length < 8) return { liquiditySweep: null, sweepQuality: 0, rejectionStrength: 0 };

  const last = candles[candles.length - 1];
  const prev = candles[candles.length - 2];
  const recent = candles.slice(-8, -1);
  const recentHigh = Math.max(...recent.map((c) => c.high));
  const recentLow = Math.min(...recent.map((c) => c.low));

  const highs: Array<[string, number | undefined]> = [
    ["recentHigh", recentHigh],
    ["asiaHigh", ranges?.asiaHigh],
    ["londonRangeHigh", ranges?.londonRangeHigh],
    ["nyRangeHigh", ranges?.nyRangeHigh],
    ["prevDayHigh", ranges?.prevDayHigh],
  ];

  for (const [name, level] of highs) {
    if (typeof level === "number" && last.high > level && last.close < level) {
      const wick = last.high - Math.max(last.open, last.close);
      const rejectionStrength = clamp(wick / candleRange(last));
      const closeBack = clamp((level - last.close) / Math.max(last.high - level, 1e-9));
      const impulse = clamp(Math.abs(last.close - prev.close) / candleRange(last));
      return {
        liquiditySweep: "buy_side",
        sweepQuality: clamp(rejectionStrength * 0.45 + closeBack * 0.35 + impulse * 0.2),
        sweptLevel: name,
        rejectionStrength,
      };
    }
  }

  const lows: Array<[string, number | undefined]> = [
    ["recentLow", recentLow],
    ["asiaLow", ranges?.asiaLow],
    ["londonRangeLow", ranges?.londonRangeLow],
    ["nyRangeLow", ranges?.nyRangeLow],
    ["prevDayLow", ranges?.prevDayLow],
  ];

  for (const [name, level] of lows) {
    if (typeof level === "number" && last.low < level && last.close > level) {
      const wick = Math.min(last.open, last.close) - last.low;
      const rejectionStrength = clamp(wick / candleRange(last));
      const closeBack = clamp((last.close - level) / Math.max(level - last.low, 1e-9));
      const impulse = clamp(Math.abs(last.close - prev.close) / candleRange(last));
      return {
        liquiditySweep: "sell_side",
        sweepQuality: clamp(rejectionStrength * 0.45 + closeBack * 0.35 + impulse * 0.2),
        sweptLevel: name,
        rejectionStrength,
      };
    }
  }

  return { liquiditySweep: null, sweepQuality: 0, rejectionStrength: 0 };
}
