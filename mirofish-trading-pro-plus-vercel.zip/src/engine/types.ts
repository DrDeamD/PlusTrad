export type MarketRegime =
  | "TREND_EXPANSION"
  | "TREND_PULLBACK"
  | "RANGE_ROTATION"
  | "LIQUIDITY_SWEEP"
  | "NEWS_VOLATILE"
  | "DEAD_MARKET";

export type SessionLabel =
  | "ASIA"
  | "LONDON_PREOPEN"
  | "LONDON"
  | "LONDON_NY_OVERLAP"
  | "NEW_YORK"
  | "LATE_NY"
  | "OFF_HOURS";

export type TradeDecision = "Buy" | "Sell" | "Wait" | "No Trade";

export type ReasonCode =
  | "TREND_OK"
  | "HTF_OK"
  | "SESSION_OK"
  | "REGIME_OK"
  | "ADX_OK"
  | "BOS_OK"
  | "SWEEP_OK"
  | "MOMENTUM_OK"
  | "RR_OK"
  | "NEWS_OK"
  | "BLOCK_NEWS"
  | "BLOCK_LOW_ADX"
  | "BLOCK_HIGH_ADX_REVERSAL"
  | "BLOCK_HTF_CONFLICT"
  | "BLOCK_SPREAD"
  | "BLOCK_LOW_RR"
  | "BLOCK_DEAD_MARKET"
  | "BLOCK_LATE_EXHAUSTION"
  | "BLOCK_WEAK_CONFLUENCE";

export type TrendBias = "bullish" | "bearish" | "neutral";
export type VolatilityState = "low" | "normal" | "high";
export type LiquiditySweepSide = "buy_side" | "sell_side" | null;
export type SetupType = "trend" | "reversal" | "breakout" | "range" | "news";
export type RiskClass = "A" | "B" | "C" | "Invalid";

export interface MultiTFState {
  m5Trend: TrendBias;
  m15Trend: TrendBias;
  h1Trend: TrendBias;
  alignedBullish: boolean;
  alignedBearish: boolean;
  conflict: boolean;
}

export interface MacdState {
  macd: number;
  signal: number;
  histogram: number;
}

export interface SessionRanges {
  asiaHigh?: number;
  asiaLow?: number;
  londonRangeHigh?: number;
  londonRangeLow?: number;
  nyRangeHigh?: number;
  nyRangeLow?: number;
  prevDayHigh?: number;
  prevDayLow?: number;
}

export interface LiquidityState {
  liquiditySweep: LiquiditySweepSide;
  sweepQuality: number;
  sweptLevel?: string;
  rejectionStrength: number;
}

export interface DiagnosticsState {
  macd: MacdState;
  m15Ema21: number;
  m15Ema50: number;
  h1Ema50: number;
  h1Ema200: number;
}

export interface AgentSignal {
  id: string;
  name: string;
  style: string;
  decision: TradeDecision;
  confidence: number;
  score: number;
  influence: number;
  reasoning: string;
  confluences: string[];
  regimeFit: number;
  sessionFit: number;
  pairFit: number;
  entry?: number | null;
  sl?: number | null;
  tp1?: number | null;
  tp2?: number | null;
  reasonCodes?: ReasonCode[];
  blocked?: boolean;
  performanceFactor?: number;
  setupType?: SetupType;
  rr?: number | null;
  riskPips?: number | null;
  rewardPips?: number | null;
  riskClass?: RiskClass;
}

export interface AgentMemoryRecord {
  trades: number;
  wins: number;
  losses: number;
  recentWinRate: number;
  byPair: Record<string, number>;
  byRegime: Record<string, number>;
  bySession: Record<string, number>;
}

export interface WeightedConsensusResult {
  direction: TradeDecision;
  signedBias: number;
  conf: number;
}

export interface ProMarketState {
  pair: string;
  last: number;
  candles: Array<{ open: number; high: number; low: number; close: number; volume: number; datetime?: string }>;
  rsi: number;
  adx: number;
  atr: number;
  ema9: number;
  ema21: number;
  ema50: number;
  macdBull: boolean;
  trend: "bullish" | "bearish";
  volatility: VolatilityState;
  session: SessionLabel;
  regime: MarketRegime;
  bos: boolean;
  bosDir: "bullish" | "bearish" | null;
  newsScore: number;
  newsImpact: "low" | "medium" | "high";
  htfTrend: TrendBias;
  liquiditySweep: LiquiditySweepSide;
  spreadPips?: number;
  multiTF?: MultiTFState;
  ranges?: SessionRanges;
  liquidity?: LiquidityState;
  diagnostics?: DiagnosticsState;
}
