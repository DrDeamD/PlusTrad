import { computeConfluenceScore, scoreToConfidence } from "./confluenceEngine";
import { getAgentMemory, memoryPerformanceFactor } from "./agentMemory";
import { RC } from "./reasonCodes";
import type { AgentSignal, ProMarketState } from "./types";

export const PRO_AGENTS = [
  { id: "london-momentum", name: "London Open Momentum", style: "Momentum" },
  { id: "ny-continuation", name: "NY Session Continuation", style: "Trend" },
  { id: "dxy-correlation", name: "DXY Correlation", style: "Macro" },
  { id: "liquidity-sweep", name: "Liquidity Sweep Reversal", style: "Reversal" },
  { id: "macro-news", name: "Macro News Reaction", style: "News" },
  { id: "trend-following", name: "Trend Following", style: "Trend" },
  { id: "mean-reversion", name: "Mean Reversion", style: "Mean Reversion" },
  { id: "price-action", name: "Price Action", style: "Price Action" },
  { id: "breakout", name: "Breakout", style: "Breakout" },
  { id: "multi-tf-judge", name: "Multi-TF Judge", style: "Judge" },
] as const;

function baseSignal(agent: { id: string; name: string; style: string }): AgentSignal {
  const perf = memoryPerformanceFactor(getAgentMemory(agent.id));
  return {
    id: agent.id,
    name: agent.name,
    style: agent.style,
    decision: "Wait",
    confidence: 0.35,
    score: 0.4,
    influence: 0.75,
    reasoning: "No edge",
    confluences: [],
    regimeFit: 0.4,
    sessionFit: 0.4,
    pairFit: 0.5,
    reasonCodes: [],
    blocked: false,
    performanceFactor: perf,
    setupType: "trend",
  };
}

function finalize(sig: AgentSignal, direction: "Buy" | "Sell" | "Wait", score: number, reasoning: string): AgentSignal {
  sig.decision = direction;
  sig.score = Number(score.toFixed(3));
  sig.confidence = Number(scoreToConfidence(score).toFixed(3));
  sig.reasoning = reasoning;
  return sig;
}

function trendAlignment(ms: ProMarketState): number {
  if (ms.htfTrend === ms.trend) return 0.9;
  if (ms.htfTrend === "neutral") return 0.55;
  return 0.25;
}

function newsContext(ms: ProMarketState): number {
  return ms.newsImpact === "low" ? 0.9 : ms.newsImpact === "medium" ? 0.55 : 0.2;
}

function sessionFitForLondon(ms: ProMarketState): number {
  return ms.session === "LONDON" ? 1 : ms.session === "LONDON_NY_OVERLAP" ? 0.82 : ms.session === "LONDON_PREOPEN" ? 0.75 : 0.2;
}

function sessionFitForNY(ms: ProMarketState): number {
  return ms.session === "NEW_YORK" ? 1 : ms.session === "LONDON_NY_OVERLAP" ? 0.9 : 0.25;
}

function chooseTrendSide(ms: ProMarketState): "Buy" | "Sell" | "Wait" {
  if (ms.htfTrend === "bullish" && ms.trend === "bullish") return "Buy";
  if (ms.htfTrend === "bearish" && ms.trend === "bearish") return "Sell";
  return "Wait";
}

function evaluateLondonMomentum(ms: ProMarketState): AgentSignal {
  const sig = baseSignal(PRO_AGENTS[0]);
  sig.setupType = "trend";
  sig.sessionFit = sessionFitForLondon(ms);
  sig.pairFit = ["EUR/USD", "GBP/USD", "XAU/USD"].includes(ms.pair) ? 1 : 0.55;
  sig.regimeFit = ["TREND_EXPANSION", "TREND_PULLBACK"].includes(ms.regime) ? 0.95 : 0.25;
  const score = computeConfluenceScore({
    regimeFit: sig.regimeFit,
    trendAlignment: trendAlignment(ms),
    structureQuality: ms.bos ? 0.9 : 0.55,
    momentumQuality: ms.macdBull === (ms.trend === "bullish") ? 0.85 : 0.35,
    sessionFit: sig.sessionFit,
    newsContext: newsContext(ms),
    htfAlignment: ms.htfTrend === ms.trend ? 0.95 : 0.25,
    liquidityContext: 0.55,
  });
  const side = ms.adx >= 18 ? chooseTrendSide(ms) : "Wait";
  if (side !== "Wait") sig.reasonCodes?.push(RC.ADX_OK, RC.SESSION_OK, RC.TREND_OK, RC.HTF_OK);
  return finalize(sig, side, score, "London momentum with trend alignment");
}

function evaluateNYContinuation(ms: ProMarketState): AgentSignal {
  const sig = baseSignal(PRO_AGENTS[1]);
  sig.setupType = "trend";
  sig.sessionFit = sessionFitForNY(ms);
  sig.pairFit = ["XAU/USD", "EUR/USD", "USD/JPY"].includes(ms.pair) ? 1 : 0.6;
  sig.regimeFit = ["TREND_EXPANSION", "TREND_PULLBACK"].includes(ms.regime) ? 0.9 : 0.3;
  const score = computeConfluenceScore({
    regimeFit: sig.regimeFit,
    trendAlignment: trendAlignment(ms),
    structureQuality: ms.bos ? 0.82 : 0.58,
    momentumQuality: ms.adx >= 20 ? 0.82 : 0.42,
    sessionFit: sig.sessionFit,
    newsContext: newsContext(ms),
    htfAlignment: ms.htfTrend === ms.trend ? 0.9 : 0.3,
    liquidityContext: 0.5,
  });
  const side = ms.adx >= 20 ? chooseTrendSide(ms) : "Wait";
  return finalize(sig, side, score, "New York continuation after established direction");
}

function evaluateDxyCorrelation(ms: ProMarketState): AgentSignal {
  const sig = baseSignal(PRO_AGENTS[2]);
  sig.setupType = "trend";
  sig.sessionFit = 0.8;
  sig.regimeFit = 0.72;
  sig.pairFit = ["XAU/USD", "EUR/USD", "GBP/USD", "USD/JPY"].includes(ms.pair) ? 1 : 0.5;
  const direction = ms.htfTrend === "bullish" ? "Buy" : ms.htfTrend === "bearish" ? "Sell" : "Wait";
  const score = computeConfluenceScore({
    regimeFit: sig.regimeFit,
    trendAlignment: trendAlignment(ms),
    structureQuality: 0.6,
    momentumQuality: ms.adx >= 18 ? 0.7 : 0.45,
    sessionFit: sig.sessionFit,
    newsContext: newsContext(ms),
    htfAlignment: ms.htfTrend === ms.trend ? 0.85 : 0.4,
    liquidityContext: 0.5,
  });
  return finalize(sig, direction, score, "Dollar correlation bias filter");
}

function evaluateLiquiditySweepReversal(ms: ProMarketState): AgentSignal {
  const sig = baseSignal(PRO_AGENTS[3]);
  sig.setupType = "reversal";
  sig.sessionFit = ["LONDON", "LONDON_NY_OVERLAP", "NEW_YORK"].includes(ms.session) ? 0.85 : 0.35;
  sig.pairFit = ["XAU/USD", "GBP/USD", "EUR/USD"].includes(ms.pair) ? 1 : 0.55;
  sig.regimeFit = ms.regime === "LIQUIDITY_SWEEP" ? 1 : 0.3;
  let direction: "Buy" | "Sell" | "Wait" = "Wait";
  let liquidityContext = 0.3;
  if (ms.liquiditySweep === "sell_side") {
    direction = "Buy";
    liquidityContext = 0.95;
    sig.reasonCodes?.push(RC.SWEEP_OK);
  } else if (ms.liquiditySweep === "buy_side") {
    direction = "Sell";
    liquidityContext = 0.95;
    sig.reasonCodes?.push(RC.SWEEP_OK);
  }
  const score = computeConfluenceScore({
    regimeFit: sig.regimeFit,
    trendAlignment: 0.52,
    structureQuality: ms.bos ? 0.6 : 0.5,
    momentumQuality: 0.5,
    sessionFit: sig.sessionFit,
    newsContext: newsContext(ms),
    htfAlignment: 0.45,
    liquidityContext,
  });
  return finalize(sig, direction, score, "Liquidity sweep reversal setup");
}

function evaluateMacroNewsReaction(ms: ProMarketState): AgentSignal {
  const sig = baseSignal(PRO_AGENTS[4]);
  sig.setupType = "news";
  sig.sessionFit = 0.8;
  sig.pairFit = ["XAU/USD", "EUR/USD", "USD/JPY", "USD/CAD"].includes(ms.pair) ? 1 : 0.6;
  sig.regimeFit = ms.regime === "NEWS_VOLATILE" ? 1 : 0.25;
  const direction = ms.newsImpact === "high" ? (ms.trend === "bullish" ? "Buy" : "Sell") : "Wait";
  const score = computeConfluenceScore({
    regimeFit: sig.regimeFit,
    trendAlignment: trendAlignment(ms),
    structureQuality: 0.55,
    momentumQuality: ms.adx >= 20 ? 0.78 : 0.45,
    sessionFit: sig.sessionFit,
    newsContext: ms.newsImpact === "high" ? 0.95 : 0.35,
    htfAlignment: ms.htfTrend === ms.trend ? 0.8 : 0.35,
    liquidityContext: 0.5,
  });
  return finalize(sig, direction, score, "Post-news reaction quality");
}

function evaluateTrendFollowing(ms: ProMarketState): AgentSignal {
  const sig = baseSignal(PRO_AGENTS[5]);
  sig.setupType = "trend";
  sig.sessionFit = 0.8;
  sig.pairFit = 0.85;
  sig.regimeFit = ["TREND_EXPANSION", "TREND_PULLBACK"].includes(ms.regime) ? 0.95 : 0.2;
  const direction = ms.adx >= 20 ? chooseTrendSide(ms) : "Wait";
  const score = computeConfluenceScore({
    regimeFit: sig.regimeFit,
    trendAlignment: trendAlignment(ms),
    structureQuality: ms.bos ? 0.75 : 0.55,
    momentumQuality: ms.adx >= 25 ? 0.9 : 0.55,
    sessionFit: sig.sessionFit,
    newsContext: newsContext(ms),
    htfAlignment: ms.htfTrend === ms.trend ? 0.95 : 0.2,
    liquidityContext: 0.45,
  });
  return finalize(sig, direction, score, "Trend-following continuation");
}

function evaluateMeanReversion(ms: ProMarketState): AgentSignal {
  const sig = baseSignal(PRO_AGENTS[6]);
  sig.setupType = "range";
  sig.sessionFit = 0.7;
  sig.pairFit = 0.75;
  sig.regimeFit = ms.regime === "RANGE_ROTATION" ? 0.95 : 0.12;
  let direction: "Buy" | "Sell" | "Wait" = "Wait";
  if (ms.regime === "RANGE_ROTATION" && ms.adx <= 18) {
    if (ms.rsi <= 30) direction = "Buy";
    else if (ms.rsi >= 70) direction = "Sell";
  }
  const score = computeConfluenceScore({
    regimeFit: sig.regimeFit,
    trendAlignment: 0.45,
    structureQuality: 0.55,
    momentumQuality: ms.rsi <= 30 || ms.rsi >= 70 ? 0.85 : 0.35,
    sessionFit: sig.sessionFit,
    newsContext: newsContext(ms),
    htfAlignment: ms.htfTrend === "neutral" ? 0.85 : 0.3,
    liquidityContext: 0.5,
  });
  return finalize(sig, direction, score, "Range rotation mean reversion");
}

function evaluatePriceAction(ms: ProMarketState): AgentSignal {
  const sig = baseSignal(PRO_AGENTS[7]);
  sig.setupType = "trend";
  sig.sessionFit = 0.82;
  sig.pairFit = 0.9;
  sig.regimeFit = ["TREND_PULLBACK", "TREND_EXPANSION", "LIQUIDITY_SWEEP"].includes(ms.regime) ? 0.88 : 0.3;
  const direction = ms.bos ? (ms.bosDir === "bullish" ? "Buy" : "Sell") : "Wait";
  const score = computeConfluenceScore({
    regimeFit: sig.regimeFit,
    trendAlignment: trendAlignment(ms),
    structureQuality: ms.bos ? 0.95 : 0.4,
    momentumQuality: ms.macdBull === (direction === "Buy") ? 0.78 : 0.4,
    sessionFit: sig.sessionFit,
    newsContext: newsContext(ms),
    htfAlignment: ms.htfTrend === ms.trend ? 0.85 : 0.35,
    liquidityContext: ms.liquiditySweep ? 0.75 : 0.45,
  });
  if (ms.bos) sig.reasonCodes?.push(RC.BOS_OK);
  return finalize(sig, direction, score, "Structure-led price action");
}

function evaluateBreakout(ms: ProMarketState): AgentSignal {
  const sig = baseSignal(PRO_AGENTS[8]);
  sig.setupType = "breakout";
  sig.sessionFit = ["LONDON", "LONDON_NY_OVERLAP", "NEW_YORK"].includes(ms.session) ? 0.9 : 0.25;
  sig.pairFit = ["GBP/USD", "EUR/USD", "XAU/USD"].includes(ms.pair) ? 0.95 : 0.65;
  sig.regimeFit = ms.regime === "TREND_EXPANSION" ? 0.95 : 0.25;
  const direction = ms.bos ? (ms.bosDir === "bullish" ? "Buy" : "Sell") : "Wait";
  const score = computeConfluenceScore({
    regimeFit: sig.regimeFit,
    trendAlignment: trendAlignment(ms),
    structureQuality: ms.bos ? 0.88 : 0.4,
    momentumQuality: ms.adx >= 22 ? 0.85 : 0.4,
    sessionFit: sig.sessionFit,
    newsContext: newsContext(ms),
    htfAlignment: ms.htfTrend === ms.trend ? 0.85 : 0.25,
    liquidityContext: ms.liquiditySweep ? 0.25 : 0.7,
  });
  return finalize(sig, direction, score, "Volatility-supported breakout");
}

function evaluateMultiTfJudge(ms: ProMarketState): AgentSignal {
  const sig = baseSignal(PRO_AGENTS[9]);
  sig.setupType = "trend";
  sig.influence = 0.95;
  sig.sessionFit = 0.8;
  sig.pairFit = 0.9;
  sig.regimeFit = 0.8;
  const direction = chooseTrendSide(ms);
  const score = computeConfluenceScore({
    regimeFit: 0.8,
    trendAlignment: trendAlignment(ms),
    structureQuality: ms.bos ? 0.7 : 0.55,
    momentumQuality: ms.adx >= 18 ? 0.7 : 0.35,
    sessionFit: 0.8,
    newsContext: newsContext(ms),
    htfAlignment: ms.htfTrend === ms.trend ? 1 : 0.2,
    liquidityContext: 0.5,
  });
  return finalize(sig, direction, score, "Multi-timeframe judge");
}

export function evaluateProAgent(agent: { id: string }, ms: ProMarketState): AgentSignal {
  switch (agent.id) {
    case "london-momentum": return evaluateLondonMomentum(ms);
    case "ny-continuation": return evaluateNYContinuation(ms);
    case "dxy-correlation": return evaluateDxyCorrelation(ms);
    case "liquidity-sweep": return evaluateLiquiditySweepReversal(ms);
    case "macro-news": return evaluateMacroNewsReaction(ms);
    case "trend-following": return evaluateTrendFollowing(ms);
    case "mean-reversion": return evaluateMeanReversion(ms);
    case "price-action": return evaluatePriceAction(ms);
    case "breakout": return evaluateBreakout(ms);
    case "multi-tf-judge": return evaluateMultiTfJudge(ms);
    default: return baseSignal({ id: agent.id, name: agent.id, style: "Unknown" });
  }
}
