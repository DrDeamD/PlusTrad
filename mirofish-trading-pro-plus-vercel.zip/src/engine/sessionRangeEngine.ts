import type { Candle } from "../services/apiService";
import type { SessionRanges } from "./types";

function rangeFrom(candles: Candle[]): { high?: number; low?: number } {
  if (!candles.length) return {};
  return {
    high: Math.max(...candles.map((c) => c.high)),
    low: Math.min(...candles.map((c) => c.low)),
  };
}

export function computeSessionRanges(candles: Candle[]): SessionRanges {
  if (!candles.length) return {};
  const asia = candles.slice(-72, -54);
  const london = candles.slice(-54, -42);
  const ny = candles.slice(-42, -30);
  const prevDay = candles.slice(-96, -72);

  const asiaRange = rangeFrom(asia);
  const londonRange = rangeFrom(london);
  const nyRange = rangeFrom(ny);
  const prevRange = rangeFrom(prevDay);

  return {
    asiaHigh: asiaRange.high,
    asiaLow: asiaRange.low,
    londonRangeHigh: londonRange.high,
    londonRangeLow: londonRange.low,
    nyRangeHigh: nyRange.high,
    nyRangeLow: nyRange.low,
    prevDayHigh: prevRange.high,
    prevDayLow: prevRange.low,
  };
}
