import type { AgentSignal, ProMarketState, RiskClass } from "./types";

function roundByPair(pair: string, value: number): number {
  const digits = pair === "XAU/USD" ? 2 : 5;
  return Number(value.toFixed(digits));
}

function pipFactor(pair: string): number {
  if (pair === "XAU/USD") return 0.1;
  if (pair.includes("JPY")) return 0.01;
  return 0.0001;
}

function calcRR(entry: number, sl: number, tp1: number): number {
  const risk = Math.abs(entry - sl);
  const reward = Math.abs(tp1 - entry);
  return risk <= 0 ? 0 : reward / risk;
}

export function buildRiskModel(params: { signal: AgentSignal; ms: ProMarketState }): {
  entry: number | null;
  sl: number | null;
  tp1: number | null;
  tp2: number | null;
  rr: number | null;
  riskPips: number | null;
  rewardPips: number | null;
  riskClass: RiskClass;
} {
  const { signal, ms } = params;
  if (signal.decision !== "Buy" && signal.decision !== "Sell") {
    return { entry: null, sl: null, tp1: null, tp2: null, rr: null, riskPips: null, rewardPips: null, riskClass: "Invalid" as const };
  }

  const entry = ms.last;
  const atr = ms.atr || entry * 0.001;
  const isBuy = signal.decision === "Buy";
  let sl: number;
  let tp1: number;
  let tp2: number;

  if (signal.setupType === "reversal") {
    sl = isBuy ? entry - atr * 1.25 : entry + atr * 1.25;
    tp1 = isBuy ? entry + atr * 2 : entry - atr * 2;
    tp2 = isBuy ? entry + atr * 3 : entry - atr * 3;
  } else if (signal.setupType === "breakout") {
    sl = isBuy ? entry - atr * 1.45 : entry + atr * 1.45;
    tp1 = isBuy ? entry + atr * 2.4 : entry - atr * 2.4;
    tp2 = isBuy ? entry + atr * 3.5 : entry - atr * 3.5;
  } else {
    sl = isBuy ? entry - atr * 1.6 : entry + atr * 1.6;
    tp1 = isBuy ? entry + atr * 2.5 : entry - atr * 2.5;
    tp2 = isBuy ? entry + atr * 3.8 : entry - atr * 3.8;
  }

  const rr = calcRR(entry, sl, tp1);
  const riskPips = Math.abs(entry - sl) / pipFactor(ms.pair);
  const rewardPips = Math.abs(tp1 - entry) / pipFactor(ms.pair);
  const riskClass: RiskClass = rr < 1.6 ? "Invalid" : rr >= 2.2 ? "A" : rr >= 1.8 ? "B" : "C";

  return {
    entry: roundByPair(ms.pair, entry),
    sl: roundByPair(ms.pair, sl),
    tp1: roundByPair(ms.pair, tp1),
    tp2: roundByPair(ms.pair, tp2),
    rr: Number(rr.toFixed(2)),
    riskPips: Number(riskPips.toFixed(1)),
    rewardPips: Number(rewardPips.toFixed(1)),
    riskClass,
  };
}
