import type { MarketRegime, SessionLabel } from "./types";

type WeightedMap<T extends string> = Record<T, number>;

export interface AgentProfile {
  pairWeights: Record<string, number>;
  regimeWeights: WeightedMap<MarketRegime>;
  sessionWeights: WeightedMap<SessionLabel>;
  minAdx: number;
  maxSpread: number;
}

export const AGENT_PROFILES: Record<string, AgentProfile> = {
  "London Open Momentum": {
    pairWeights: { "XAU/USD": 0.9, "EUR/USD": 1, "GBP/USD": 1, "USD/JPY": 0.55, "AUD/USD": 0.5, "USD/CAD": 0.45 },
    regimeWeights: { TREND_EXPANSION: 1, TREND_PULLBACK: 0.9, RANGE_ROTATION: 0.2, LIQUIDITY_SWEEP: 0.4, NEWS_VOLATILE: 0.15, DEAD_MARKET: 0.05 },
    sessionWeights: { ASIA: 0.1, LONDON_PREOPEN: 0.8, LONDON: 1, LONDON_NY_OVERLAP: 0.85, NEW_YORK: 0.45, LATE_NY: 0.15, OFF_HOURS: 0.05 },
    minAdx: 18,
    maxSpread: 3,
  },
};
