import type { AgentMemoryRecord } from "./types";

const memory = new Map<string, AgentMemoryRecord>();

function blankRecord(): AgentMemoryRecord {
  return {
    trades: 0,
    wins: 0,
    losses: 0,
    recentWinRate: 0.5,
    byPair: {},
    byRegime: {},
    bySession: {},
  };
}

export function getAgentMemory(agentId: string): AgentMemoryRecord {
  if (!memory.has(agentId)) memory.set(agentId, blankRecord());
  return memory.get(agentId)!;
}

export function updateAgentMemory(params: {
  agentId: string;
  pair: string;
  regime: string;
  session: string;
  won: boolean;
}): void {
  const record = getAgentMemory(params.agentId);
  record.trades += 1;
  if (params.won) record.wins += 1;
  else record.losses += 1;
  record.recentWinRate = record.wins / Math.max(1, record.trades);
  record.byPair[params.pair] = (record.byPair[params.pair] ?? 0) + (params.won ? 1 : -1);
  record.byRegime[params.regime] = (record.byRegime[params.regime] ?? 0) + (params.won ? 1 : -1);
  record.bySession[params.session] = (record.bySession[params.session] ?? 0) + (params.won ? 1 : -1);
}

export function memoryPerformanceFactor(record: AgentMemoryRecord): number {
  return Math.max(0.4, Math.min(1.25, 0.8 + record.recentWinRate * 0.4));
}
