import type { MarketRegime, ProMarketState } from "./types";

export function detectMarketRegime(ms: ProMarketState): MarketRegime {
  if (ms.newsImpact === "high") return "NEWS_VOLATILE";
  if (ms.volatility === "low" && ms.adx < 15) return "DEAD_MARKET";
  if (ms.liquidity?.liquiditySweep || ms.liquiditySweep) return "LIQUIDITY_SWEEP";
  if (ms.adx >= 28 && ms.bos) return "TREND_EXPANSION";
  if (ms.adx >= 20) return "TREND_PULLBACK";
  return "RANGE_ROTATION";
}
