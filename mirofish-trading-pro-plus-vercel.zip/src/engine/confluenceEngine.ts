import type { AgentSignal, WeightedConsensusResult } from "./types";

export function computeConfluenceScore(params: {
  regimeFit: number;
  trendAlignment: number;
  structureQuality: number;
  momentumQuality: number;
  sessionFit: number;
  newsContext: number;
  htfAlignment?: number;
  liquidityContext?: number;
}): number {
  const score =
    params.regimeFit * 0.2 +
    params.trendAlignment * 0.16 +
    params.structureQuality * 0.16 +
    params.momentumQuality * 0.12 +
    params.sessionFit * 0.1 +
    params.newsContext * 0.12 +
    (params.htfAlignment ?? 0.5) * 0.08 +
    (params.liquidityContext ?? 0.5) * 0.06;
  return Math.max(0, Math.min(1, score));
}

export function scoreToConfidence(score: number): number {
  return Math.max(0.28, Math.min(0.95, 0.25 + score * 0.75));
}

export function computeWeightedConsensus(signals: AgentSignal[]): WeightedConsensusResult {
  let signedBias = 0;
  let gross = 0;
  for (const signal of signals) {
    const sign = signal.decision === "Buy" ? 1 : signal.decision === "Sell" ? -1 : 0;
    const perf = signal.performanceFactor ?? 1;
    const weight = (signal.influence ?? 0.5) * (signal.confidence ?? 0.5) * (signal.score ?? 0.5) * perf;
    signedBias += sign * weight;
    gross += Math.abs(weight);
  }
  const direction = Math.abs(signedBias) < 1.8 ? "Wait" : signedBias > 0 ? "Buy" : "Sell";
  const conf = gross <= 0 ? 0.5 : Math.max(0.3, Math.min(0.95, Math.abs(signedBias) / gross + 0.35));
  return { direction, signedBias: Number(signedBias.toFixed(3)), conf: Number(conf.toFixed(2)) };
}
