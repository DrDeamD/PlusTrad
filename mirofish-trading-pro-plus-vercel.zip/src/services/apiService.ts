import {
  calculateADX,
  calculateATR,
  calculateEMA,
  calculateMACD,
  calculateRSI,
  classifyVolatility,
} from "../engine/indicatorEngine";
import { detectLiquidityState } from "../engine/liquidityEngine";
import { buildMultiTFState } from "../engine/multiTimeframeEngine";
import { computeSessionRanges } from "../engine/sessionRangeEngine";
import type { ProMarketState, TrendBias } from "../engine/types";

const TWELVEDATA_KEY = (import.meta.env.VITE_TWELVEDATA_KEY ?? "").trim();
const LIVE_DATA_ENABLED = TWELVEDATA_KEY.length > 0;

export interface Candle {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  datetime?: string;
}

export interface NewsItem {
  headline: string;
  source: string;
  time: string;
  sentiment: number;
  isHighImpact: boolean;
  relevance?: number;
}

export interface FetchCandlesResult {
  candles: Candle[];
  isReal: boolean;
}

export interface BuildProMarketStateParams {
  pair: string;
  m5Candles: Candle[];
  m15Candles: Candle[];
  h1Candles: Candle[];
  news: NewsItem[];
}

function normalizePairForTwelveData(pair: string): string {
  return pair.replace("/", "");
}

function safeNumber(value: unknown, fallback = 0): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function average(values: number[], fallback = 0): number {
  return values.length ? values.reduce((a, b) => a + b, 0) / values.length : fallback;
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function roundByPair(pair: string, value: number): number {
  const digits = pair === "XAU/USD" ? 2 : 5;
  return Number(value.toFixed(digits));
}

function getTrendFromCloses(closes: number[]): TrendBias {
  if (closes.length < 55) return "neutral";
  const ema21 = calculateEMA(closes, 21);
  const ema50 = calculateEMA(closes, 50);
  const last = closes[closes.length - 1];
  if (ema21 > ema50 && last >= ema21) return "bullish";
  if (ema21 < ema50 && last <= ema21) return "bearish";
  return "neutral";
}

function deriveHtfTrend(h1Candles: Candle[]): TrendBias {
  if (h1Candles.length < 60) return "neutral";
  const closes = h1Candles.map((c) => c.close);
  const ema50 = calculateEMA(closes, 50);
  const ema200 = closes.length >= 200 ? calculateEMA(closes, 200) : calculateEMA(closes, 100);
  const last = closes[closes.length - 1];
  if (ema50 > ema200 && last >= ema50) return "bullish";
  if (ema50 < ema200 && last <= ema50) return "bearish";
  return "neutral";
}

function detectBOS(candles: Candle[], atr: number): { bos: boolean; bosDir: "bullish" | "bearish" | null } {
  if (candles.length < 8) return { bos: false, bosDir: null };
  const last = candles[candles.length - 1];
  const recent = candles.slice(-7, -1);
  const prevHigh = Math.max(...recent.map((c) => c.high));
  const prevLow = Math.min(...recent.map((c) => c.low));
  const buffer = atr * 0.18;
  if (last.close > prevHigh + buffer) return { bos: true, bosDir: "bullish" };
  if (last.close < prevLow - buffer) return { bos: true, bosDir: "bearish" };
  return { bos: false, bosDir: null };
}

function classifyNewsImpact(news: NewsItem[]): "low" | "medium" | "high" {
  if (!news.length) return "low";
  const highImpactCount = news.filter((n) => n.isHighImpact).length;
  const avgAbsSentiment = average(news.map((n) => Math.abs(n.sentiment)), 0);
  if (highImpactCount >= 2 || (highImpactCount >= 1 && avgAbsSentiment >= 0.55)) return "high";
  if (highImpactCount >= 1 || avgAbsSentiment >= 0.3) return "medium";
  return "low";
}

function estimateSpreadPips(pair: string, candles: Candle[]): number {
  const avgRange = average(candles.slice(-10).map((c) => c.high - c.low), 0);
  if (pair === "XAU/USD") return clamp(avgRange * 2.2, 12, 35);
  if (pair.includes("JPY")) return clamp((avgRange / 0.01) * 0.08, 0.8, 3.5);
  return clamp((avgRange / 0.0001) * 0.06, 0.7, 3.0);
}

function generateSimulatedCandles(pair: string, count = 120): Candle[] {
  const base =
    pair === "XAU/USD" ? 2650 :
    pair === "EUR/USD" ? 1.085 :
    pair === "GBP/USD" ? 1.274 :
    pair === "USD/JPY" ? 151.2 :
    pair === "AUD/USD" ? 0.662 : 1.356;

  const step = pair === "XAU/USD" ? 1.8 : pair.includes("JPY") ? 0.12 : 0.0014;
  const candles: Candle[] = [];
  let price = base;

  for (let i = 0; i < count; i += 1) {
    const drift = Math.sin(i / 7) * step * 0.12;
    const move = (Math.random() - 0.49) * step + drift;
    const open = price;
    const close = price + move;
    const high = Math.max(open, close) + Math.random() * step * 0.5;
    const low = Math.min(open, close) - Math.random() * step * 0.5;
    candles.push({ open, high, low, close, volume: Math.floor(Math.random() * 6000) + 2000 });
    price = close;
  }

  return candles;
}

export async function fetchCandlesWithFallback(
  pair: string,
  interval: "5min" | "15min" | "1h" = "5min",
  outputsize = 180,
): Promise<FetchCandlesResult> {
  const symbol = normalizePairForTwelveData(pair);

  if (!LIVE_DATA_ENABLED) {
    const fallbackCount = interval === "1h" ? 220 : interval === "15min" ? 160 : 140;
    return {
      candles: generateSimulatedCandles(pair, fallbackCount),
      isReal: false,
    };
  }

  try {
    const url =
      `https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(symbol)}` +
      `&interval=${encodeURIComponent(interval)}` +
      `&outputsize=${encodeURIComponent(String(outputsize))}` +
      `&timezone=UTC` +
      `&apikey=${encodeURIComponent(TWELVEDATA_KEY)}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`TwelveData HTTP ${res.status}`);
    const data = await res.json();
    if (!data?.values || !Array.isArray(data.values) || data.values.length < 30) {
      throw new Error("Invalid candle payload");
    }
    const candles: Candle[] = data.values
      .map((v: Record<string, unknown>) => ({
        open: safeNumber(v.open),
        high: safeNumber(v.high),
        low: safeNumber(v.low),
        close: safeNumber(v.close),
        volume: safeNumber(v.volume),
        datetime: typeof v.datetime === "string" ? v.datetime : undefined,
      }))
      .filter((c: Candle) => c.open > 0 && c.high > 0 && c.low > 0 && c.close > 0 && c.high >= c.low)
      .reverse();

    if (candles.length < 30) throw new Error("Not enough clean candles");
    return { candles, isReal: true };
  } catch {
    const fallbackCount = interval === "1h" ? 220 : interval === "15min" ? 160 : 140;
    return { candles: generateSimulatedCandles(pair, fallbackCount), isReal: false };
  }
}

export async function fetchNewsWithFallback(pair: string): Promise<{ news: NewsItem[]; isReal: boolean }> {
  try {
    return {
      news: [
        {
          headline: `Live context update for ${pair}`,
          source: "System Feed",
          time: new Date().toISOString(),
          sentiment: 0,
          isHighImpact: false,
          relevance: 0.7,
        },
      ],
      isReal: false,
    };
  } catch {
    return {
      news: [
        {
          headline: `Fallback market context for ${pair}`,
          source: "Fallback Feed",
          time: new Date().toISOString(),
          sentiment: 0,
          isHighImpact: false,
          relevance: 0.5,
        },
      ],
      isReal: false,
    };
  }
}

export function buildProMarketState(params: BuildProMarketStateParams): ProMarketState {
  const { pair, m5Candles, m15Candles, h1Candles, news } = params;
  if (m5Candles.length < 60) throw new Error(`Not enough M5 candles for ${pair}`);
  if (m15Candles.length < 60) throw new Error(`Not enough M15 candles for ${pair}`);
  if (h1Candles.length < 60) throw new Error(`Not enough H1 candles for ${pair}`);

  const last = m5Candles[m5Candles.length - 1];
  const m5Closes = m5Candles.map((c) => c.close);
  const m15Closes = m15Candles.map((c) => c.close);
  const h1Closes = h1Candles.map((c) => c.close);

  const ema9 = calculateEMA(m5Closes, 9);
  const ema21 = calculateEMA(m5Closes, 21);
  const ema50 = calculateEMA(m5Closes, 50);
  const rsi = calculateRSI(m5Closes, 14);
  const atr = calculateATR(m5Candles, 14);
  const adx = calculateADX(m5Candles, 14);
  const macd = calculateMACD(m5Closes);

  const rawTrend = getTrendFromCloses(m5Closes);
  const trend: "bullish" | "bearish" = rawTrend === "neutral" ? (last.close >= ema21 ? "bullish" : "bearish") : rawTrend;
  const htfTrend = deriveHtfTrend(h1Candles);
  const multiTF = buildMultiTFState({ m5Candles, m15Candles, h1Candles });
  const ranges = computeSessionRanges(m5Candles);
  const liquidity = detectLiquidityState({ candles: m5Candles, ranges });
  const { bos, bosDir } = detectBOS(m5Candles, atr);

  const newsScore = clamp(
    average(news.map((n) => n.sentiment * (typeof n.relevance === "number" ? n.relevance : 0.7)), 0),
    -1,
    1,
  );
  const newsImpact = classifyNewsImpact(news);
  const volatility = classifyVolatility(atr, last.close);
  const spreadPips = estimateSpreadPips(pair, m5Candles);

  return {
    pair,
    last: roundByPair(pair, last.close),
    candles: m5Candles,
    rsi: Number(rsi.toFixed(2)),
    adx: Number(adx.toFixed(2)),
    atr: roundByPair(pair, atr),
    ema9: roundByPair(pair, ema9),
    ema21: roundByPair(pair, ema21),
    ema50: roundByPair(pair, ema50),
    macdBull: macd.histogram >= 0,
    trend,
    volatility,
    session: "LONDON",
    regime: "TREND_EXPANSION",
    bos,
    bosDir,
    newsScore: Number(newsScore.toFixed(3)),
    newsImpact,
    htfTrend,
    liquiditySweep: liquidity.liquiditySweep,
    spreadPips: Number(spreadPips.toFixed(2)),
    multiTF,
    ranges,
    liquidity,
    diagnostics: {
      macd: {
        macd: Number(macd.macd.toFixed(5)),
        signal: Number(macd.signal.toFixed(5)),
        histogram: Number(macd.histogram.toFixed(5)),
      },
      m15Ema21: roundByPair(pair, calculateEMA(m15Closes, 21)),
      m15Ema50: roundByPair(pair, calculateEMA(m15Closes, 50)),
      h1Ema50: roundByPair(pair, calculateEMA(h1Closes, 50)),
      h1Ema200: roundByPair(pair, h1Closes.length >= 200 ? calculateEMA(h1Closes, 200) : calculateEMA(h1Closes, 100)),
    },
  };
}
